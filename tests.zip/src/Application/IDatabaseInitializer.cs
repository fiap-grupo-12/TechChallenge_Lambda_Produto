﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIAP.TechChallenge.LambdaProduto.Application
{
    public interface IDatabaseInitializer
    {
        void Initialize();
    }
}
