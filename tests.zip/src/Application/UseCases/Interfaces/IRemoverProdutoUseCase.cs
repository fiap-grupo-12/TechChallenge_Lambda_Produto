﻿namespace FIAP.TechChallenge.LambdaProduto.Application.UseCases.Interfaces
{
    public interface IRemoverProdutoUseCase : IUseCaseAsync<int, bool>
    {
    }
}
