﻿namespace FIAP.TechChallenge.LambdaProduto.Domain.Entities
{
    public class Categoria : EntityBase
    {
        public string Nome { get; set; }
    }
}
